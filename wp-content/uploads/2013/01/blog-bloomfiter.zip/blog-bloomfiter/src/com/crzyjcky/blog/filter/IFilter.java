package com.crzyjcky.blog.filter;

public interface IFilter {

	public void addData(String key);
	public boolean isExist(String key);
}