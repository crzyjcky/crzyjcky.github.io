package com.crzyjcky.blog.filter;

import java.util.HashSet;

//implementation
public class NormalFilter implements IFilter {

	private HashSet<String> keySet = new HashSet<String>();
	
	@Override
	public void addData(String key) {
		
		keySet.add(key);
	}

	@Override
	public boolean isExist(String key) {
		
		return keySet.contains(key);
	}
}