package com.crzyjcky.blog;

import com.crzyjcky.blog.filter.BloomFilter;
import com.crzyjcky.blog.filter.IFilter;
import com.crzyjcky.blog.filter.NormalFilter;

public class Main {

	private static IFilter filter = new BloomFilter();
	//private static IFilter filter = new NormalFilter();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		// add as much data as you want here  here
		
		printAddData("hello");
		printAddData("I");
		printAddData("am");
		printAddData("happy");
		
		System.out.println("==================================================");
		System.out.println("                        RESULT                    ");
		System.out.println("==================================================");
		
		// testing
		printIsExist("world");
		printIsExist("wo");
		printIsExist("w");
		printIsExist("happy");
		printIsExist("hap");
		printIsExist("I");
		
	}
	
	private static void printAddData(String key) {
		
		System.out.println("---------------------------------");
		System.out.println("addData(" + key + ")");
		filter.addData(key);
		
	}
	
	private static void printIsExist(String key) {
		
		System.out.println("---------------------------------");
		System.out.println("isExist(" + key + "):\t" + filter.isExist(key));
	}
}
