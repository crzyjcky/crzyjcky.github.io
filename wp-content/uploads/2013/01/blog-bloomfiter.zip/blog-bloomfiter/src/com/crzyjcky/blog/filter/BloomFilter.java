package com.crzyjcky.blog.filter;

public class BloomFilter implements IFilter {

	private int bloomBitArray;
	
	@Override
	public void addData(String key) {
		
		int hashKey = hash(key);

		System.out.println("bloomBitArray (before):\t" + toBinaryString(bloomBitArray));
		System.out.println("hashKey:\t\t\td\t" + toBinaryString(hashKey));
		
		bloomBitArray = hashKey | bloomBitArray;
		
		System.out.println("bloomBitArray (after):\t" + toBinaryString(bloomBitArray));
	}
	
	@Override
	public boolean isExist(String key) {
		
		int hashKey = hash(key);
		
		System.out.println("bloomBitArray:\t" + toBinaryString(bloomBitArray));
		System.out.println("hashKey:\t\t" + toBinaryString(hashKey));
		
		return (bloomBitArray & hashKey) == hashKey;
	}
	
	// it can be 1 or more hash functions
	private int hash(String key) {
		
		// you can use your own hash code, even as simple as modulo hash code,
		// I use Java built-in hashcode to illustrate the purpose.
		
		// set up 1 bit in the bloomBitArray
		return 1 << key.hashCode();	
	}
	
	// beautify the result
	private String toBinaryString(int key) {
		
		return padLeft(Integer.toBinaryString(key));
	}
	
	// beautify the result
	private String padLeft(String binaryString) {
		
		return String.format("%32s", binaryString).replace(" ", "0");
	}
}