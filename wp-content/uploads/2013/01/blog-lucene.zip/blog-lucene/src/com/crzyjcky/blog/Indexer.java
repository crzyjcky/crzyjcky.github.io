package com.crzyjcky.blog;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;


public class Indexer {

	private static final String INDEX_DIR = "index";
	private static final String DATA_DIR = "data";
	
	private IndexWriter indexWriter;
	
	public void index(String indexDir, String dataDir) throws IOException {
		
		Directory dir = FSDirectory.open(new File(indexDir));
		indexWriter = new IndexWriter(dir, new StandardAnalyzer(Version.LUCENE_30), true, IndexWriter.MaxFieldLength.UNLIMITED);
		
		File[] files = new File(DATA_DIR).listFiles();
		for (File file : files) {
			
			Document doc = new Document();
			doc.add(new Field("contents", new FileReader(file)));
			doc.add(new Field("filename", file.getName(), Field.Store.YES, Field.Index.NOT_ANALYZED));
			
			indexWriter.addDocument(doc);
			System.out.println("doc added: " + file.getName());
		}
	}
	
	public void close() throws CorruptIndexException, IOException {
		
		indexWriter.close();
	}
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		System.out.println("start: " + System.currentTimeMillis());
		
		Indexer indexer = new Indexer();
		indexer.index(INDEX_DIR, DATA_DIR);
		indexer.close();
		
		System.out.println("end: " + System.currentTimeMillis());
	}
}
