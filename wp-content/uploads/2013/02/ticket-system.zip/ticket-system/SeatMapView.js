var SeatMapView = function(seatMapElement) {
  var COLOR_RED = "#F79F81";
  var COLOR_GREEN = "ACFA58";
  
  this.onChange = function(data) {
    for (var a in data) {
      var element = document.getElementById(a);
      element.bgColor = data[a] ? COLOR_RED : COLOR_GREEN;
    }
  }
  
  this.init = function(data) {
    this.onChange(data);
  }
}