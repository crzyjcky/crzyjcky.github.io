var Model = function() {
  
  // initialization, false = is vacant, not occupied yet
  var seatMap = {};
  seatMap["A1"] = false;
  seatMap["A2"] = false;
  seatMap["A3"] = false;
  seatMap["B1"] = false;
  seatMap["B2"] = false;
  seatMap["B3"] = false;
  seatMap["C1"] = false;
  seatMap["C2"] = false;
  seatMap["C3"] = false;

  var listeners = [];
  
  this.addListener = function(listener) {
    listeners.push(listener);
  }

  this.removeListener = function(listener) {
    var i = listeners.length;
    while (i--) {
      if (listeners[i] === listener) {
        listeners.splice(i, 1);
        break;
      }
    }
  }
  
  var broadcast = function(event, args) {
    var len = listeners.length;
    for (var i = 0; i < len; i++) {
      listeners[i][event](args);
    }
  }
  
  // listener of dom element
  this.onClickHandler = function(e) {
    var element = e.target;
    
    if (!isExist(element.id)) {
      return;
    }

    // toggle value
    seatMap[element.id] = !seatMap[element.id];
    broadcast("onChange", seatMap);
  }

  this.getData = function() {
    return seatMap;
  }

  var isExist = function(item) {
    for (var a in seatMap) {
      if (a === item) {
        return true;
      }
    }
    return false;
  }
  
  var toggle = function(value) {
    value = !value;
    
    console.log(seatMap["A1"]);
    
    broadcast("onChange", seatMap);
  }
  
}