var SelectedSeatView = function(selectedSeatElement) {
  this.onChange = function(data) {
    selectedSeatElement.innerHTML = "";
    for (var a in data) {
      if (data[a]) {
        selectedSeatElement.innerHTML += a + "\n";
      }
    }
  }
  
  this.init = function(data) {
    this.onChange(data);
  }
}