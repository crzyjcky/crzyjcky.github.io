var PriceCalculatorView = function(priceCalculatorElement) {
  var UNIT_PRICE = 10.00;
  
  this.onChange = function(data) {
    var numberOfSeat = calculateNumberOfSeat(data);
    priceCalculatorElement.value = numberOfSeat + " (seats) x $" + UNIT_PRICE + " (unit price) = $" + (numberOfSeat * UNIT_PRICE);
  }
  
  this.init = function(data) {
    this.onChange(data);
  }
  
  var calculateNumberOfSeat = function(data) {
    var numberOfSeat = 0;
    for (var a in data) {
      if (data[a]) {
        numberOfSeat++;
      }
    }
    return numberOfSeat;
  }
}